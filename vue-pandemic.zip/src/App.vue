<template>
  <div id="app">
    <router-view />
  </div>
</template>

<style lang="less">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #d984f3;
  // background-image: url("assets/bg2.jpg");
  background-image: url("https://z3.ax1x.com/2021/11/14/I61SUS.jpg");
  background-repeat: no-repeat;
  background-position: 130% 120%;
  background-position: center;

  width: 100vw;
  height: 100vh;
  max-width: 100vw;
  max-height: 100vh;
}
</style>
