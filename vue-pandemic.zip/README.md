# vue-pandemic
![图片信息描述](https://github.com/shaobaitao/vue-pandemic/blob/master/demo.png)
## About
```
Author : Ethan Shao
Date : November 15, 2021
API : Sina pandemic api
Demo : https://shaobaitao.cn/pandemic
```

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
